package com.fundproj.moneyTransfer.dto;

import java.io.Serializable;

public class BaseModel implements Serializable {

}
