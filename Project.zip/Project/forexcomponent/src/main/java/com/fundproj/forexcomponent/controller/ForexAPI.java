package com.fundproj.forexcomponent.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.fundproj.forexcomponent.dto.ForexRequest;
import com.fundproj.forexcomponent.dto.ForexResponse;
import com.fundproj.forexcomponent.service.ForexManager;

@RestController
@RequestMapping("api")
public class ForexAPI {

	
	@Autowired
	private ForexManager fxService;
	
	
	@PostMapping(value="/fx", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ForexResponse> getForexRates(@RequestBody ForexRequest fxReq){
		ForexResponse rs =  fxService.getRates(fxReq);
		
		return new ResponseEntity<ForexResponse>(rs, HttpStatus.OK);
		
	}
}
