package com.fundproj.forexcomponent.dto;

import java.io.Serializable;

public class BaseModel implements Serializable{

}
