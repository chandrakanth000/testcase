package com.fundproj.forexcomponent.service;

import com.fundproj.forexcomponent.dto.ForexRequest;
import com.fundproj.forexcomponent.dto.ForexResponse;

public interface ForexManager {
	
public ForexResponse getRates(ForexRequest req);

}
