package com.fundproj.Credit.Credit.config;

public class KafkaTopicConfig {

}
