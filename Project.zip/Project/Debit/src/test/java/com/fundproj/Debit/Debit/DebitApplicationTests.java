package com.fundproj.Debit.Debit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DebitApplicationTests {

	@Test
	void contextLoads() {
	}

}
